<template>
	<div style="background-color: orange;">

		<v-row class="px-3" dense>
			<v-col cols="7" md="6" dense  >
				<v-avatar class="mx-auto">
					<img
					src="/data/br1.jpeg"
					>
				</v-avatar>
				<v-btn text>Sri Kanchi Kamakshi Ambal</v-btn>
			</v-col>
			<v-col cols="5" md="6"  dense justify="end" >
				<div class="mx-auto text-center">
					<v-btn fab small dark color="indigo" class="mr-0"><v-icon>mdi-facebook</v-icon></v-btn>
					<v-btn fab small dark color="blue" class="mr-0"><v-icon>mdi-twitter</v-icon></v-btn>
					<v-btn fab small dark color="red" class="mr-0"><v-icon>mdi-youtube</v-icon></v-btn>
				</div>
			</v-col>	
		</v-row>
		
	</div>
</template>

<script type="text/javascript">

	export default{
	}
</script>

<style lang="css" scoped>
</style>

