<template>
	<div class="pb-6" >
		<v-container  >
			<v-row wrap class="mx-auto text-center" height="700px" >
				<v-col cols="12" md="6"  >
					<h1 class="text-h5 text-center pb-3">Kanchipuram temple</h1>
					<iframe class="mx-auto text-center elevation-20" width="90%" height="300px" src="https://www.youtube.com/embed/RmXNLG3HXkc" frameborder="10" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
				</v-col>

				<v-col cols="12" md="6">
					<h1 class="text-h5 text-center pb-3">Sri Kanchi kamakshi Temple</h1>
					<iframe class="mx-auto text-center elevation-20" width="90%" height="300px" src="https://www.youtube.com/embed/Bo9uT5gkrdc" frameborder="10" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
				</v-col>
				<v-col cols="12">
					<v-btn link to="/gallery/videos" tile outlined >View More</v-btn>
				</v-col>
			</v-row>
		</v-container>
	</div>
</template>

<script type="text/javascript">
	export default{

	}
</script>