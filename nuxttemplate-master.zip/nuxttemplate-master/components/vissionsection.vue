<template>
	<div data-aos="fade-up" data-aos-duration="700">
		<v-container>
			<v-row class="pa-3" >
				<v-col cols="12" md="5">
					<v-img src="/data/ramachandra.jpg" aspect-ratio="1"></v-img>
				</v-col>
				<v-col cols="12" md="7">
					<h1 class="text-h6 py-3 purple--text">Brahmasri Neelakkal C.N.Ramachandra Sastrigal</h1>
					<p> Brahmasri Neelakkal C.N.Ramachandra Sastrigal in the service Sri Kamakshi Ammal <br> <br>The ancient text ‘Sowbhagya Chintamani’ provides a valuable account of Sri Kanchi Kamakshi Amman temple and the traditional families that were conducting worship and rituals in the temple. According to it, families belonging to six Gothrams were ordained this great duty of worship. But centuries ago, families belonging to four Gothrams left Kanchipuram for Thanjavur (then Tanjore) for various historical reasons. At present, only two families of Bharatwaja Gothram and one family of Kausika Gothram are residing in Kanchipuram and conducting rituals in the temple with hereditary rights.
					<br>
					The family of Brahmasri Neelakkal Ramachandra Sastrigal belongs to Bharathwaja Gothram and is called as the grand old ‘Neelakkal Lineage</p>
					<div>
						<v-btn tile outlined link to="/about/priest">Learn More</v-btn>
					</div>
				</v-col>
			</v-row>

<!-- 		<v-row data-aos="slide-up" data-aos-duration="1000">		
			<v-col cols="12" md="6" >
				<h1 class="text-h4 py-3 purple--text">Plan a Trip</h1>
				<p>Content will be Updated here</p>
			</v-col>
				<v-col cols="12" md="6">
				<v-img src="/profile.jpg" aspect-ratio="1.77"></v-img>
			</v-col>
		</v-row> -->
	</v-container>
</div>
</template>

<script type="text/javascript">
	export default{
		name:"vissionsection",
		data(){
			return{

			}
		},

	}
</script>