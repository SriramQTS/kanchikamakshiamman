<template>
	<div>
		<div data-aos="slide-up" data-aos-duration="1000">
			<v-container class="px-3 pt-4">
				<h1 class="text-h5 text-center pa-3">Videos Section</h1>
				<v-row wrap>
					<v-col cols="12" md="6">
						<iframe width="100%" height="300px" class="mx-auto text-center"  src="https://www.youtube.com/embed/LM9lUutFtb4" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
					</v-col>
					<v-col cols="12" md="6">
						<iframe width="100%" height="300px"  src="https://www.youtube.com/embed/IXO_Ka3t95c" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
					</v-col>
					<v-col cols="12" md="6">
						<iframe width="100%" height="300px"  src="https://www.youtube.com/embed/JbQ9rbUJEm0" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
					</v-col>
					<v-col cols="12" md="6">
						<iframe width="100%" height="300px"  src="https://www.youtube.com/embed/xQmmC521uxw" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
					</v-col>
					<v-col cols="12" md="6">
						<iframe width="100%" height="300px"  src="https://www.youtube.com/embed/m0oHocQ5dPk" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
					</v-col>
					<v-col cols="12" md="6">
						<iframe width="100%" height="300px"  src="https://www.youtube.com/embed/sIqEhtWryvQ" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
					</v-col>
					<v-col cols="12" md="6">
						<iframe width="100%" height="300px"  src="https://www.youtube.com/embed/rpyYi3tkMmk" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
					</v-col>
					<v-col cols="12" md="6">
						<iframe width="100%" height="300px"  src="https://www.youtube.com/embed/fc67n1wVG04" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

					</v-col>
				</v-row>
			</v-container>
		</div>
	</div>
</template>

<script type="text/javascript">
	export default{
		layout:"page",
		data(){
			return{
			}
		}
	}
</script>