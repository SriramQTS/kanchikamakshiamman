<template>
	<div>
		<v-container class="pa-2">
			<v-row wrap>
				<v-col cols="12">
				</v-col>
			</v-row>
		</v-container>
	</div>
</template>