<template>
	<div>
		<v-container>

			<v-row id="section2">

				<v-col cols="12" md="6">
					<h1 class="text-h3">Saraswathi pooja</h1>
					<h2 class="text-h4 purple--text pt-6">25 October</h2>
					<p class="pt-6">Vasant Panchami is the festival dedicated to goddess Saraswati who is their goddess of knowledge, language, music and all arts.</p>
				</v-col>
				<v-col cols="12" md="6">
					<v-img src="/events/saraswathi.jpg" aspect-ratio="1.5" height="300"></v-img>
				</v-col>
			</v-row>

			<v-row id="section3">
				<v-col cols="12" md="6">
					<v-img src="/events/dhasara.webp" aspect-ratio="1.5" height="300"></v-img>
				</v-col>
				<v-col cols="12" md="6">
					<h1 class="text-h3">Vijayadashami</h1>
					<h2 class="text-h4 purple--text pt-6">26 Octobr</h2>
					<p class="pt-6">Vijayadashami also known as Dussehra, Dasara or Dashain is a major Hindu festival celebrated at the end of Navaratri every year.</p>
				</v-col>
			</v-row>
		</v-container>
	</div>
</template>

<script type="text/javascript">
	export default{
		layout:"page"
	}
</script>

