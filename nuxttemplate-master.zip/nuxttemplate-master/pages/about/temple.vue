<template>
	<div>
		<v-container class="pa-3">
			<v-row>
				<v-col cols="12" class="mx-auto">
					<h1 class="text-h3 text-center pa-3">About Kanchi Kamakshi Temple</h1>
					<v-img width="700" class="mx-auto" src="/indeximg/bannerwall.jpg"></v-img>
					<p class="text-h6 pa-6">
						Kanchi Kamakshi temple is situated at about 5 acres of land and has four entrances. The main entrance of the temple has a Kalabhairavar deity on its left and the Mahishasura Mardini deity on the right. On the centre of the entrance you can see a huge Dwajasthampa. Moving further to the entrance of the Kamakshi deity you can see a Vinayaga deity. Moving on a straight line further, Goddess Kamakshi is visible. Goddess Kamakshi is surrounded by deities of Ayyapan, Saraswati, Annaporani and Adisankaracharya on its outer prakaram. The Goddess also has Varahi, Arupalakshmi Kalvarperumal (one of the 108 Divya Desam of Vaishanavities), Roopalakshmi and Arthanariswarar deities surrounding the sanctorum of Goddess on its Gayatri Mandapam. There is Santhanasthampam inside the prakaram of Goddess which is called the Nabisthan of the Goddess. There is a Srichakra Yantra (Sri Kamakoti Peetam) established by Jagadguru Sri Adisankaracharya in front of the Goddess deity. There is also a temple tank inside the premises. Kamakshi temple has a close relation with the Sri Kanchi Kamakoti Peetam and its successive Sankarcharyas. The temple has a gallery of Adisankarcharya's Life history inside the temple premises itself. Goddess Kamakshi is the main deity and the temple is one of the fifty one Shakti peetas. The temple is spelled as Nabisthana - Ottiyana peetam. The temple also has a golden Gopuram on the sanctorum of the Goddess Kamakshi deity which is visible to all devotees.
					</p>
				</v-col>
			</v-row>
		</v-container>
	</div>
</template>

<script>
	export default{
		layout:"page"
	}
</script>