<template>
	<div>
		<v-container class="pa-3">
			<v-row>
				<v-col cols="12" class="mx-auto">
					<h1 class="text-h4 text-center pa-3">Brahmasri Neelakkal C.N.Ramachandra Sastrigal in the service Sri Kamakshi Ammal</h1>
					<v-row>
						<v-col cols="12" md="6">
							<!-- <v-img class="mx-auto" width="400px" src="/data/ramachandra.jpg"></v-img> -->
							<v-img class="mx-auto" width="400px" src="/data/priest3.jpeg"></v-img>
						</v-col>
						<v-col cols="12" md="6">
							<p>
								The ancient text ‘Sowbhagya Chintamani’ provides a valuable account of Sri Kanchi Kamakshi Amman temple and the traditional families that were conducting worship and rituals in the temple. According to it, families belonging to six Gothrams were ordained this great duty of worship. But centuries ago, families belonging to four Gothrams left Kanchipuram for Thanjavur (then Tanjore) for various historical reasons. At present, only two families of Bharatwaja Gothram and one family of Kausika Gothram are residing in Kanchipuram and conducting rituals in the temple with hereditary rights.
							</p>
							<p>
								The family of Brahmasri Neelakkal Ramachandra Sastrigal belongs to Bharathwaja Gothram and is called as the grand old ‘Neelakkal Lineage’. The ancestors of this lineage are as follows:
							</p>
							<ul>
								<li>Sri Neelakkal Arunachala Sastrigal – His son</li>
								<li>Sri Neelakkal Ramaswamy Sastrigal – His son</li>
								<li>Sri Neelakkal Kachapeswara Sastrigal – His son</li>
								<li>Sri Neelakkal Krishna Sastrigal – His son</li>
								<li>Sri Neelakkal Muthuswamy Sastrigal – Srimathi Dharmasamvardhini Ammal, (Dharmasamvardhini Ammal was also called ‘Dharmambal’. She was the granddaughter of Sri Syama Sastrigal – one among the Carnatic Music Trinity) _ Their son,</li>
								<li>Sri Neelakkal Nataraja Sastrigal – Srimathi Alamelu Ammal,(Father of Alamelu Ammal served in the then princely State of Pudukkottai holding an important position). Their son,</li>
								<li>Sri Neelakkal Ramachandra Sastrigal – Srimathi Alamelu Ammal</li>
							</ul>
						</v-col>
					</v-row>
					
					<v-row wrap>
						<v-col cols="12">
							<h1 class="text-h4 text-center">Birth and Siblings</h1>	
							<p>Sri Ramachandra Sastrigal was born in the year 1938 (Tamil year Vegudhanya) under auspicious Vaikasi Pooram star. He was brought up in their ancestral home situated in the Sri Kamakshi Ambal Sannidhi Street.He continues to live there. Sri Ramachandra Sastrigal has two sisters (elder Kamakshi and younger sister Jayalakshmi) and one younger brother, Muthuswamy Sastrigal.</p>

							<h1 class="text-h4 text-center">School Education</h1>	
							<p>To anyone obsessed with the degree and rank seeking formal education structure of these days, it might appear that his academic qualifications were meagre and only at the school level. But the standard of education and the commitment of teachers of those days laid a strong foundation in pupils in the elementary stage that enabled them to pursue traditional scriptural study directly under the guidance of gurus. Thus Sri Ramachandra Sastrigal studied up to third standard in the S.S.K.V school. After that with a double promotion he was admitted to the fifth standard in the K.M. Subbarayar school. Again with a double promotion he moved on to the seventh standard. In that school, Sri Ramachandra Sastrigal studied up to eighth standard. After that, he took up traditional Vedic studies and acquited himself creditably and to the satisfaction of his masters.</p>

							<h1 class="text-h4 text-center">Upanayanam and Vedic Education</h1>	
							<p>In the year 1949, at the age of 11 years, Upanayanam was performed to Sastrigal. After that he was sent to a Vedic school situated in the Keezh Ambi village, to the west of Kanchipuram town. There he studied Tharkam (Logic), Vyakaranam (Grammar), Vedanta (Vedic Philosophy), Mimamsa, etc. Erudite scholars in Vedic literature of that time in south India taught Sri Ramachandra Sastrigal in the Kizh Ambi Veda Patashala. Pandit Vepathur Sri Subramanya Sastrigal, Chidambaram Sri Ranganatha Sastrigal, Bolagam Sri Rama Sastrigal, Andhra Mandali Sri Venkatesa Sastrigal, Sri S.R. Krishnamurthy Sastrigal taught pupils in the Veda Patashala. It is useful to recall here that Sri Kanchi Kamakoti 69th Pitathipathi Sri Jayendra Saraswati Sankaracharya Swamigal also learnt in Orikkai along with Sri Ramachandra Sastrigal.

							Nothing could give greater elation and spiritual solace than the fact that Sri Kanchi Kamakoti 68th Pitathipathi, Maha Periyava Sri Chandrasekarendra Saraswati Sankaracharya Swamigal himself taught Ramachandra Sastrigal in Orikkai. He studied Bhardruhari (Vairagya Sadhakam) under Kanchi Periyava. Further, in Thiruvanaikkaval near Trichi, he studied under Vidhyasthanam Sri T.S. Balakrishna Sastrigal. He was taught Siddhantha Lesa Sangraha and given Pareeksha in Advaitha Sadas in the year 1960-62.</p>
						</v-col>
					</v-row>
					
						
					</p>
				</v-col>
			</v-row>
		</v-container>
	</div>
</template>

<script>
	export default{
		layout:"page"
	}
</script>