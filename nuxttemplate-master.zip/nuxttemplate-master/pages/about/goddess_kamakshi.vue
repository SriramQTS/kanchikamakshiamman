<template>
	<div>
		<v-container class="pa-3">
			<v-row>
				<v-col cols="12">
					<h1 class="text-h3 text-center pa-3">About Goddess Kamakshi</h1>
					<v-img width="500" class="mx-auto" src="/fsimg/n3.jpeg"></v-img>
					<p class="text-h6 pa-6">
						The Goddess Kamakshi is in a sitting posture in the temple. This posture is called the Padmasana posture. The Padmasana posture is said to resemble a lotus. In the Yogic practice this resembles the form of meditation. The Goddess holds a Sugarcane bow on her left upper arm and Lotus, Parrot in her right upper arm. The Goddess also has divine chakras called Pasa and Angusa in her arms.
						<br> <br>
						The Goddess also has a Chandraperai (a shape of moon like structure) in her forehead. The Goddess Kamakshi is situated in the middle of temple premises.
						<br> <br>
						History reveals that Goddess Kamakshi was praying under a mango tree with a Shiva lingam made of sand to marry the great Lord Shiva. After a long duration of dedicated and devoted meditation to Lord Shiva, Lord Shiva appeared before her and married the Goddess Kamakshi, a divine form of Parvati. There are no traditional Parvati or Shakti shrines in the city of Kanchipuram, apart from this temple, which adds even more legend to this temple.
					</p>
				</v-col>
			</v-row>
		</v-container>
	</div>
</template>

<script>
	export default{
		layout:"page"
	}
</script>