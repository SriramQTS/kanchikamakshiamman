<template>
	<div>
		<v-container>
			<v-row dense>
				<v-col cols="12" color="blue">
					<h1 class="text-h3 text-center">How to Reach</h1>
				</v-col>
				<v-col cols="12">
					Kamatchi Amman Temple is located in Kanchipuram. It is well connected to the rest of the city through various modes of transport.
				</v-col>

				<v-col cols="12">
					<strong>Airport</strong>
					<v-list-item dense>1. Chennai to Kanchipuram</v-list-item>
					<v-list-item dense>2. Madurai to Kanchipuram</v-list-item>
					<v-list-item dense>3. Kanyakumari to Kanchipuram</v-list-item>
				</v-col>
				<v-col cols="12" >
					<strong>Railway</strong>
					<v-list-item dense>1. Chennai to Kanchipuram</v-list-item>
					<v-list-item dense>2. Madurai to Kanchipuram</v-list-item>
					<v-list-item dense>3. Kanyakumari to Kanchipuram</v-list-item>
				</v-col>

				<v-col cols="12" md="12">
					<iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d15560.159923981824!2d79.703183!3d12.840693!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xeb0a104aa53ed53!2sSri%20Kanchi%20Kamakshi%20Amma%20Temple!5e0!3m2!1sen!2sin!4v1602819629812!5m2!1sen!2sin" width="100%" height="500px" frameborder="" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
				</v-col>
			</v-row>
		</v-container>
	</div>
</template>

<script type="text/javascript">
	export default{
		layout:"page"
	}
</script>