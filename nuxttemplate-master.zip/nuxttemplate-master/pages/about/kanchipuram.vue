<template>
	<div>
		<v-container class="pa-3">
			<v-row>
				<v-col cols="12">
					<h1 class="text-h3 text-center pa-3">About Kanchipuram - City Of Temples</h1>
					<v-img width="500" class="mx-auto" src="/data/templetower.jpg"></v-img>
					<p class="text-h6 pa-6">
						Kanchipuram is one of the seven sacred cities in India. History proclaims that Kanchipuram was ruled by the Pallava Kings. The city is most famous for its silk production and old temples. The city is located on the Palar river. The city has all types of people from weavers to Vaishnavites. The city has many big temples like Sri Kamakshi Amman Temple, Sri Ekambaranthar Temple, Sri Varadaraja Perumal Temple, Sri Ulagalanda Perumal Temple, Sri Kumarakottam Temple, Sri Kailasanathar Temple, Sri Kachapeswarar Temple and much more. The city also attracts tourist and foreigners in plenty due to its rich culture and heritage. The city has a huge spree of Silk Weavers Society. The city is quite famous all over the world for its Silk Variety and Quality. There is huge demand for export of Silk saris within and outside India. There are many eminent scholars like C.N.Annadurai who were born in this city. The city has developed a niche for the industrial corridors for great giants like Nokia, Motorola, Hyundai and many other. The city also has hotels and restaurants for the comfort of tourist and foreigners. There is a very old Mutt established by Sri Adisankaracharya Called Sri Kanchi Kamakoti Peetam. This mutt is world renowned for its charitable activities and Institutions. There are also other Spiritual mutts within Kanchipuram.
					</p>
				</v-col>
			</v-row>
		</v-container>
	</div>
</template>

<script>
	export default{
		layout:"page"
	}
</script>