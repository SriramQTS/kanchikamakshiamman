<template>
	<div>
		<v-container>
			<v-row>
				<v-col cols="12" class="mx-auto">
					<h1 class="text-h3 text-center">404 Not Found</h1>
					<p class="text-center mt-6"><v-btn tile link to="/"> Go to Home Page</v-btn></p>
				</v-col>
			</v-row>

		</v-container>
	</div>
</template>

<script type="text/javascript">
	export default{
		layout:"page"
	}
</script>