<template>
  <v-app id="root">
    <v-main>
     <nuxt/>
   </v-main>
 </v-app> 
</template>

<script>

  export default {
    data() {
      return{

      }
    },

  }
</script>

<style scoped>
*{
  overflow-x: hidden;
}
</style>
